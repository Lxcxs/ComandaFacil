import { FaCircle } from "react-icons/fa";
import { Container, Header, MenuContent, Categories, MenuList, Item } from "./styles";
import Input from "../../components/Forms/Input";

// Tipos para categorias e itens
interface MenuItem {
    id: number;
    name: string;
    description: string;
    price: string;
    imageUrl: string;
}

interface Category {
    id: number;
    name: string;
    items: MenuItem[];
}

// Lista de categorias e itens
const categories: Category[] = [
    {
        id: 1,
        name: "Burgers",
        items: [
            {
                id: 1,
                name: "Classic Cheeseburger",
                description: "A juicy beef patty with melted cheddar cheese, lettuce, tomato, and our special sauce.",
                price: "R$ 24,90",
                imageUrl: "https://images.tcdn.com.br/img/img_prod/832602/noticia_17733781276603f26fd6998.png",
            },
            {
                id: 2,
                name: "Bacon Deluxe",
                description: "A double patty burger with crispy bacon, cheddar cheese, and BBQ sauce.",
                price: "R$ 29,90",
                imageUrl: "https://images.tcdn.com.br/img/img_prod/832602/noticia_17733781276603f26fd6998.png",
            },
        ],
    },
    {
        id: 2,
        name: "Pizzas",
        items: [
            {
                id: 3,
                name: "Pepperoni Pizza",
                description: "A classic pepperoni pizza with a crispy crust and a rich tomato sauce.",
                price: "R$ 39,90",
                imageUrl: "https://images.tcdn.com.br/img/img_prod/832602/noticia_17733781276603f26fd6998.png",
            },
            {
                id: 4,
                name: "Margarita Pizza",
                description: "Fresh mozzarella, basil, and tomato on a thin, crispy crust.",
                price: "R$ 35,90",
                imageUrl: "https://images.tcdn.com.br/img/img_prod/832602/noticia_17733781276603f26fd6998.png",
            },
        ],
    },
    {
        id: 3,
        name: "Beverages",
        items: [
            {
                id: 5,
                name: "Coca-Cola",
                description: "A refreshing 350ml can of Coca-Cola.",
                price: "R$ 5,90",
                imageUrl: "https://images.tcdn.com.br/img/img_prod/832602/noticia_17733781276603f26fd6998.png",
            },
            {
                id: 6,
                name: "Orange Juice",
                description: "Freshly squeezed orange juice, served chilled.",
                price: "R$ 8,90",
                imageUrl: "https://images.tcdn.com.br/img/img_prod/832602/noticia_17733781276603f26fd6998.png",
            },
        ],
    },
];

function CustomerMenu() {
    return (
        <Container>
            <Header>
                <img src="https://www.shutterstock.com/image-vector/image-icon-600nw-211642900.jpg" alt="Restaurant Logo" />
                <div className="header_info">
                    <h3>Lorem Ipsum</h3>
                    <span><FaCircle /> Aberto</span>
                </div>
            </Header>

            <MenuContent>
                {/* Categorias de navegação */}
                <Categories>
                    {categories.map(category => (
                        <a key={category.id} href={`#category${category.id}`}>
                            {category.name}
                        </a>
                    ))}
                </Categories>

                {/* Campo de busca */}
                <Input type="search" name="search" label="Pesquisar" placeholder="Pesquisar no cardápio" required={false} />

                {/* Lista de itens do menu */}
                <MenuList>
                    {categories.map(category => (
                        <div className="categories" key={category.id}>
                            <h2 id={`category${category.id}`}>{category.name}</h2>
                            <div className="section">
                                {category.items.map(item => (
                                    <Item key={item.id}>
                                        <div className="item_info">
                                            <h3>{item.name}</h3>
                                            <p>{item.description}</p>
                                            <h3>{item.price}</h3>
                                        </div>
                                        <img src={item.imageUrl} alt={item.name} />
                                    </Item>
                                ))}
                            </div>
                        </div>
                    ))}
                </MenuList>
            </MenuContent>
        </Container>
    );
}

export { CustomerMenu };
